# inera.core.template#2.2.1: Inera FHIR Implementation Guide Template(sv)

## Pages

* [Hem](index.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Testning och validering](testing.md)
* [Om](about.md)
* [Versionshistorik](version-history.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Säkerhet och behörighet](security.md)
* [Mappning till profiler](mappings.md)
* [Inledning](introduction.md)
* [CapabilityStatement](capabilitystatement.md)
* [Användningsfall](use-cases.md)
* [Förväntade svar](expected-responses.md)
* [Nedladdningar](downloads.md)
* [Felhantering](error-handling.md)
* [Informationsunderlag](information-basis.md)

## Resources

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)

### ImplementationGuides

* [Inera FHIR Implementation Guide Template](ImplementationGuide-inera.core.template.md)

### Examples

* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
