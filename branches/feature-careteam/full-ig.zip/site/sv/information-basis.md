# Informationsunderlag - Inera FHIR CareTeam v0.9

## Informationsunderlag

Denna implementationsguide bygger på det informatikarbete som genomförts för informationsmängden **Fasta kontakter** inom uppdraget Sammanhållen planering på 1177.

Det informatiska underlaget beskriver begrepp, informationsbehov och informationsstruktur för fasta kontakter. IG:n realiserar relevanta delar av detta underlag med HL7 FHIR.

De fullständiga begrepps- och informationsmodellerna återges inte i denna IG. I stället hänvisas till de informatiska leveranser som ligger till grund för profileringen.

| | | |
| :--- | :--- | :--- |
| **Fasta kontakter – Begrepps- och informationsmodell** | 1.1, 2025-12-04 | Begreppsmodell, definitioner samt informationsmodell med klasser, attribut, datatyper, identifierare och kodverk. |
| **Fasta kontakter – Sammanfattande dokument för informatikarbetet i projekt Sammanhållen planering** | 1.1, 2025-12-04 | Bakgrund, beskrivning av olika typer av fasta kontakter, informationsbehov, kartläggning av regional förmåga och övergripande teknisk inriktning. |
| **Tjänstekontraktsbeskrivning GetCareManagers**(riv:coreprocess:residentparticipation:residentparticipation) | 1.0 | Tjänstekontrakt för att hämta en patients fasta kontakter enligt RIV-TA, med meddelandemodell och fältregler. |

### Källor

Informationsmodellen och det sammanfattande dokumentet finns publicerade på Ineras samarbetsyta för [Fasta kontakter](https://inera.atlassian.net/wiki/spaces/SP1177/pages/5323817048/Fasta+kontakter).

Tjänstekontraktsbeskrivningen kommer att publiceras på [rivta.se](https://rivta.se). Länk till dokumentet läggs till när det är publicerat.

### Hur underlaget används

* [Mappning mot informationsmodellen](mappings.md) beskriver hur informationsmodellen har realiserats med FHIR-resurser och profiler, samt designbeslut och avvikelser.
* [Mappning mot GetCareManagers](mapping-getcaremanagers.md) beskriver hur tjänstekontraktet motsvaras av profilerna.

