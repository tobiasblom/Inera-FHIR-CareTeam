# inera.fhir.careteam#0.9: Inera FHIR CareTeam(sv)

## Pages

* [Hem](index.md)
* [Användningsfall](use-cases.md)
* [Om](about.md)
* [Testning och validering](testing.md)
* [Felhantering](error-handling.md)
* [Inledning](introduction.md)
* [Mappning till profiler](mappings.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Förväntade svar](expected-responses.md)
* [Nedladdningar](downloads.md)
* [CapabilityStatement](capabilitystatement.md)
* [Säkerhet och behörighet](security.md)
* [Versionshistorik](version-history.md)
* [Informationsunderlag](information-basis.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Roller och ansvar](roles-and-responsibilities.md)

## Resources

### CodeSystems

* [Typ av CareTeam](CodeSystem-typ-av-careteam-cs.md)
* [Typ av fast kontakt](CodeSystem-typ-av-fast-kontakt-cs.md)

### ValueSets

* [Typ av CareTeam](ValueSet-typ-av-careteam-vs.md)
* [Typ av fast kontakt](ValueSet-typ-av-fast-kontakt-vs.md)
* [Veckodag](ValueSet-weekday-vs.md)

### Resource Profiles

* [Fast kontakt](StructureDefinition-riv-care-manager-careteam.md)
* [Team](StructureDefinition-riv-managing-team-careteam.md)

### Extensions

* [Tillgänglighet för kontaktväg](StructureDefinition-contact-point-availability.md)
* [Kontakt via team](StructureDefinition-contact-via-team.md)

### ImplementationGuides

* [Inera FHIR CareTeam](ImplementationGuide-inera.fhir.careteam.md)

### Examples

* [ExampleCareManager (CareTeam)](CareTeam-ExampleCareManager.md)
* [ExampleCareManagerAnnanFastKontakt (CareTeam)](CareTeam-ExampleCareManagerAnnanFastKontakt.md)
* [Norra teamet (CareTeam)](CareTeam-ExampleManagingTeam.md)
* [Vårdcentralen Solrosen (Organization)](Organization-ExampleOrganization.md)
* [ExamplePatient (Patient)](Patient-ExamplePatient.md)
* [ExamplePractitioner (Practitioner)](Practitioner-ExamplePractitioner.md)
* [ExamplePractitionerRole (PractitionerRole)](PractitionerRole-ExamplePractitionerRole.md)
