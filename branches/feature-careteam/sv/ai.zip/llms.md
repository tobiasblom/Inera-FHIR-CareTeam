# inera.fhir.careteam#0.9: Inera FHIR CareTeam(sv)

## Pages

* [Hem](index.md)
* [Nedladdningar](downloads.md)
* [Testning och validering](testing.md)
* [Förväntade svar](expected-responses.md)
* [CapabilityStatement](capabilitystatement.md)
* [Felhantering](error-handling.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Användningsfall](use-cases.md)
* [Informationsunderlag](information-basis.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Versionshistorik](version-history.md)
* [Inledning](introduction.md)
* [Om](about.md)
* [Mappning till profiler](mappings.md)
* [Innehåll](menu.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Säkerhet och behörighet](security.md)

## Resources

### CodeSystems

* [Typ av CareTeam](CodeSystem-typ-av-careteam-cs.md)
* [Typ av fast kontakt](CodeSystem-typ-av-fast-kontakt-cs.md)

### ValueSets

* [Urval typ av CareTeam](ValueSet-typ-av-careteam-vs.md)
* [Urval typ av fast kontakt](ValueSet-typ-av-fast-kontakt-vs.md)

### Resource Profiles

* [Fast kontakt](StructureDefinition-riv-care-manager-careteam.md)
* [Team](StructureDefinition-riv-managing-team-careteam.md)

### Extensions

* [Period för tillgänglig tid](StructureDefinition-available-time-period.md)
* [Tillgänglighet för kontaktväg](StructureDefinition-contact-point-availability.md)
* [Kontakt via team](StructureDefinition-contact-via-team.md)

### ImplementationGuides

* [Inera FHIR CareTeam](ImplementationGuide-inera.fhir.careteam.md)

### Examples

* [ExampleCareManager (CareTeam)](CareTeam-ExampleCareManager.md)
* [ExampleCareManagerAnnanFastKontakt (CareTeam)](CareTeam-ExampleCareManagerAnnanFastKontakt.md)
* [Norra teamet (CareTeam)](CareTeam-ExampleManagingTeam.md)
* [Vårdcentralen Solrosen (Organization)](Organization-ExampleOrganization.md)
* [ExamplePatient (Patient)](Patient-ExamplePatient.md)
* [ExamplePractitioner (Practitioner)](Practitioner-ExamplePractitioner.md)
* [ExamplePractitionerRole (PractitionerRole)](PractitionerRole-ExamplePractitionerRole.md)
